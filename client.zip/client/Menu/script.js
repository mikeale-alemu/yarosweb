document.addEventListener('DOMContentLoaded', function() {
    const foodItems = document.querySelectorAll('.food-item');
    const foodSections = document.querySelectorAll('.food-section');

    foodItems.forEach(item => {
        item.addEventListener('click', function() {
            const selectedFood = this.dataset.food;
            showFoodSection(selectedFood);
        });
    });

    function showFoodSection(food) {
        foodSections.forEach(section => {
            if (section.id === food) {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';
            }
        });
    }

    // Show the first food section by default
    showFoodSection('pizza');
});


function toggleMenu() {
    const burgerIcon = document.querySelector('.navList');
    burgerIcon.classList.toggle('open');
}







////////////////////
///
document.querySelectorAll('.order-btn').forEach(button => {
    button.addEventListener('click', function() {
        const foodItem = this.getAttribute('data-food');
        const foodPrice = parseFloat(this.getAttribute('data-price'));
        const foodImage = this.getAttribute('data-image');
        
        // Retrieve current quantity
        let quantity = parseInt(this.parentElement.querySelector('.quantity-badge').textContent, 10);
        
        // Increment quantity
        quantity++;
        
        // Update quantity badge
        this.parentElement.querySelector('.quantity-badge').textContent = quantity;
        
        // Store selected item and quantity in local storage
        let selectedItems = JSON.parse(localStorage.getItem('selectedItems')) || [];
        
        // Check if item already exists
        let existingItem = selectedItems.find(item => item.foodItem === foodItem);
        
        if (existingItem) {
            // Update quantity of existing item
            existingItem.quantity = quantity;
        } else {
            // Add new item
            selectedItems.push({ foodItem, foodImage, foodPrice, quantity });
        }
        
        localStorage.setItem('selectedItems', JSON.stringify(selectedItems));
    });
});


// Checkout button event listener
document.getElementById('checkoutButton').addEventListener('click', function() {
    // Redirect to order summary page
    window.location.href = 'order-summary.html';
});

//smthn
document.addEventListener('DOMContentLoaded', function() {
    // Retrieve the selected items from local storage
    let selectedItems = JSON.parse(localStorage.getItem('selectedItems')) || [];
    
    // Get the order summary and total elements
    const orderSummaryElement = document.getElementById('order-summary');
    const orderTotalElement = document.getElementById('order-total');

    // Display the order items
    let total = 0;
    selectedItems.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.innerHTML = `
            <img src="${item.foodImage}" alt="${item.foodItem}" style="width:50px;height:50px;">
            <span>${item.foodItem} - $${item.foodPrice} x ${item.quantity}</span>
        `;
        orderSummaryElement.appendChild(itemElement);
        total += item.foodPrice * item.quantity;
    });

    // Display the total price
    orderTotalElement.textContent = total.toFixed(2);

    // Check if user is authenticated
    let user = JSON.parse(localStorage.getItem('user'));

    if (!user) {
        alert('You need to be logged in to confirm the order.');
        window.location.href = 'login.html'; // Redirect to login page
        return;
    }

    // Add event listener to the confirm order button
    document.getElementById('confirmOrderButton').addEventListener('click', function() {
        // Create the order details object
        const orderDetails = {
            userId: user.id, // Include user ID
            items: selectedItems,
            total: total,
            date: new Date().toISOString()
        };

        // Send the order details to the server (using a hypothetical endpoint)
        fetch('https://example.com/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${user.token}` // Include user token for authentication
            },
            body: JSON.stringify(orderDetails)
        })
        .then(response => response.json())
        .then(data => {
            // Order confirmed, clear local storage and redirect to a confirmation page
            localStorage.removeItem('selectedItems');
            alert('Order confirmed! Your order number is ' + data.orderId);
            window.location.href = 'order-confirmation.html';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('There was an error confirming your order. Please try again.');
        });
    });
});
